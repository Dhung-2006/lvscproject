from docx2pdf import convert

# 設定要轉換的資料夾路徑
folder_path = "./alreadyPDF/011101.docx"

# 執行轉換
convert(folder_path)

